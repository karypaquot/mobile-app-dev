In this lab assignment you will learn how to code several activities, how to go from one to another and 
back, how to share data between activities, how to set up transitions between them, and how to save 
the state of an app and retrieve it whenever the user starts the app again (i.e., how to make the data 
persistent). We build a mortgage calculator app as a vehicle to learn all these concepts. 
Use the Navigation Graphs to navigate from one fragment to another. 
